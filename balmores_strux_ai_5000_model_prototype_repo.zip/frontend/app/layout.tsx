import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Balmores Strux AI",
  description: "Prototype structural analysis workspace powered by a trained ETABS brain.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
