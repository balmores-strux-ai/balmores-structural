"use client";

import { useMemo, useState } from "react";
import ThreeViewer from "@/components/ThreeViewer";
import BarMiniChart from "@/components/BarMiniChart";
import { sendChat, queueVerify } from "@/lib/api";

type Card = { label: string; value: string; unit?: string; tone?: string };
type Recommendation = { title: string; detail: string; severity: string };
type Message = { role: string; content: string };

const initialPrompt = `Design-check a 4-storey steel building, 12m x 18m, 3 bays by 3 bays, fc 30 MPa, fy 420 MPa, SBC 150 kPa, fixed supports, rigid diaphragm, braced frame, use Canada code. Give beam shear, beam moments, column axial, joint reactions, drift in mm, and recommended beam/column groups.`;

export default function HomePage() {
  const [projectId, setProjectId] = useState<string | null>(null);
  const [code, setCode] = useState("Canada");
  const [prompt, setPrompt] = useState(initialPrompt);
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Describe your structure in natural language. You can also give dimensions, supports, materials, SBC, or even coordinate-style input." },
  ]);
  const [assumptions, setAssumptions] = useState<string[]>([]);
  const [geometry, setGeometry] = useState<any>(null);
  const [cards, setCards] = useState<Card[]>([]);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [questions, setQuestions] = useState<string[]>([]);
  const [confidence, setConfidence] = useState("Unknown");
  const [details, setDetails] = useState<any>(null);
  const [verifyStatus, setVerifyStatus] = useState<string>("Not started");

  const chartData = useMemo(() => {
    if (!details?.raw_predictions) return null;
    return {
      forceItems: [
        { label: "Beam Shear", value: details.raw_predictions.max_beam_shear_kN || 0, unit: "kN" },
        { label: "Beam Moment", value: details.raw_predictions.max_beam_moment_kNm || details.raw_predictions.beam_m3_grav_kNm || 0, unit: "kNm" },
        { label: "Column Axial", value: details.raw_predictions.max_column_axial_kN || details.raw_predictions.col_p_grav_kN || 0, unit: "kN" },
        { label: "Joint Reaction V", value: details.raw_predictions.max_joint_reaction_vertical_kN || 0, unit: "kN" },
      ],
      driftItems: [
        { label: "Max Drift", value: details.raw_predictions.max_drift_mm || 0, unit: "mm" },
        { label: "Roof Disp.", value: (details.raw_predictions.worst_roof_disp_m || 0) * 1000, unit: "mm" },
        { label: "Base Shear", value: details.raw_predictions.worst_base_shear_kN || 0, unit: "kN" },
      ],
    };
  }, [details]);

  async function onSend() {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const res = await sendChat({ project_id: projectId, message: prompt, code });
      setProjectId(res.project_id);
      setMessages((prev) => [...prev, { role: "user", content: prompt }, ...res.messages]);
      setAssumptions(res.assumptions || []);
      setGeometry(res.geometry);
      setCards(res.result_cards || []);
      setRecommendations(res.recommendations || []);
      setQuestions(res.follow_up_questions || []);
      setConfidence(res.confidence || "Unknown");
      setDetails(res.detailed_results || null);
      setPrompt("");
    } catch (err: any) {
      setMessages((prev) => [...prev, { role: "assistant", content: `Error: ${err.message}` }]);
    } finally {
      setLoading(false);
    }
  }

  async function onVerify() {
    if (!projectId) return;
    const res = await queueVerify(projectId);
    setVerifyStatus(res.message);
  }

  return (
    <div className="page">
      <div className="topbar">
        <div className="brand">
          <div className="brand-badge" />
          <div>
            <div>BALMORES STRUX AI</div>
            <div className="small-muted">5000-model prototype · instant structural analysis workspace</div>
          </div>
        </div>
        <div className="small-muted">Confidence: {confidence}</div>
      </div>

      <div className="layout">
        <div className="panel">
          <div className="panel-header">
            <strong>Chat Input</strong>
            <span className="small-muted">Natural language / STAAD-style coordinates / assumptions</span>
          </div>
          <div className="chat-scroll">
            {messages.map((m, idx) => (
              <div key={`${m.role}-${idx}`} className={`msg ${m.role}`}>
                <small>{m.role === "user" ? "You" : "Balmores Response"}</small>
                <div>{m.content}</div>
              </div>
            ))}
          </div>
          <div className="input-wrap">
            <div className="row">
              <select value={code} onChange={(e) => setCode(e.target.value)}>
                <option>Canada</option>
                <option>US</option>
                <option>Philippines</option>
              </select>
              <button className="btn" onClick={onVerify} disabled={!projectId}>Queue ETABS Verify</button>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the building, loads, supports, code, fc/fy, SBC, coordinates, or ask a follow-up."
            />
            <button className="btn" onClick={onSend} disabled={loading}>{loading ? "Thinking..." : "Send"}</button>
            <div className="small-muted">{verifyStatus}</div>
          </div>
        </div>

        <div className="panel">
          <div className="viewer-shell">
            <div className="canvas-wrap">
              <ThreeViewer geometry={geometry} />
              <div className="overlay">
                <div className="tag">3D Model</div>
                <div className="tag">Live browser output</div>
                <div className="tag">ETABS-trained brain</div>
              </div>
            </div>
            <div className="bottom-split">
              <BarMiniChart title="Beam / Column / Reaction Summary" items={chartData?.forceItems || []} />
              <BarMiniChart title="Drift / Roof / Base Summary" items={chartData?.driftItems || []} />
            </div>
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <strong>Results & Recommendations</strong>
            <span className="small-muted">Instant conceptual analysis</span>
          </div>
          <div className="panel-body" style={{ maxHeight: "calc(100vh - 100px)", overflow: "auto" }}>
            <div className="result-grid">
              {cards.map((card) => (
                <div key={card.label} className="card">
                  <div className="card-label">{card.label}</div>
                  <div className={`card-value ${card.tone ? `tone-${card.tone}` : ""}`}>
                    {card.value} {card.unit || ""}
                  </div>
                </div>
              ))}
            </div>

            <div className="section">
              <h3>Assumptions used</h3>
              <div className="assumption-list">
                {assumptions.map((a, i) => <div key={i} className="li">{a}</div>)}
              </div>
            </div>

            <div className="section">
              <h3>Recommended beam / column groups</h3>
              <div className="li">
                <table className="table">
                  <thead>
                    <tr><th>Group</th><th>Scope</th><th>Design Basis</th><th>Suggested Section</th></tr>
                  </thead>
                  <tbody>
                    {details?.member_schedule?.beam_groups?.map((g: any) => (
                      <tr key={g.group}>
                        <td>{g.group}</td><td>{g.scope}</td><td>{g.design_basis}</td><td>{g.suggested_section}</td>
                      </tr>
                    ))}
                    {details?.member_schedule?.column_groups?.map((g: any) => (
                      <tr key={g.group}>
                        <td>{g.group}</td><td>{g.scope}</td><td>{g.design_basis}</td><td>{g.suggested_section}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="section">
              <h3>Recommendations</h3>
              <div className="recommendation-list">
                {recommendations.map((r, i) => (
                  <div key={i} className="li">
                    <strong>{r.title}</strong>
                    <div className="small-muted" style={{ marginTop: 6 }}>{r.detail}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="section">
              <h3>Follow-up questions</h3>
              <div className="question-list">
                {questions.map((q, i) => <div key={i} className="li">{q}</div>)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
