"use client";

export default function BarMiniChart({
  title,
  items,
}: {
  title: string;
  items: { label: string; value: number; unit?: string }[];
}) {
  const max = Math.max(...items.map((x) => x.value), 1);
  return (
    <div className="chart-card">
      <div style={{ fontWeight: 700, marginBottom: 12 }}>{title}</div>
      <div style={{ display: "grid", gap: 10 }}>
        {items.map((item) => (
          <div key={item.label}>
            <div className="small-muted" style={{ display: "flex", justifyContent: "space-between" }}>
              <span>{item.label}</span>
              <span>{item.value.toFixed(1)} {item.unit || ""}</span>
            </div>
            <div style={{ height: 10, background: "rgba(255,255,255,.06)", borderRadius: 999, overflow: "hidden", marginTop: 6 }}>
              <div
                style={{
                  width: `${(item.value / max) * 100}%`,
                  height: "100%",
                  background: "linear-gradient(135deg, #4f8cff, #72e7d1)",
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
