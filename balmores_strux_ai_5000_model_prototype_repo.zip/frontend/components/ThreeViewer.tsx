"use client";

import { Canvas } from "@react-three/fiber";
import { OrbitControls, Line } from "@react-three/drei";
import { useMemo } from "react";

type NodeT = { id: string; x: number; y: number; z: number };
type MemberT = { id: string; start: string; end: string; kind: string };

function MemberLines({
  nodes,
  members,
}: {
  nodes: NodeT[];
  members: MemberT[];
}) {
  const nodeMap = useMemo(() => {
    const map = new Map<string, [number, number, number]>();
    for (const n of nodes) map.set(n.id, [n.x, n.z, n.y]);
    return map;
  }, [nodes]);

  return (
    <>
      {members.map((m) => {
        const a = nodeMap.get(m.start);
        const b = nodeMap.get(m.end);
        if (!a || !b) return null;
        const color =
          m.kind === "column"
            ? "#7dd3fc"
            : m.kind === "brace"
            ? "#f59e0b"
            : m.kind === "cantilever"
            ? "#fb7185"
            : "#a7f3d0";
        return (
          <Line
            key={m.id}
            points={[a, b]}
            color={color}
            lineWidth={1.5}
          />
        );
      })}
    </>
  );
}

export default function ThreeViewer({
  geometry,
}: {
  geometry: { nodes: NodeT[]; members: MemberT[]; meta?: Record<string, unknown> } | null;
}) {
  return (
    <Canvas camera={{ position: [24, 20, 24], fov: 50 }}>
      <color attach="background" args={["#0d1326"]} />
      <ambientLight intensity={0.8} />
      <directionalLight position={[10, 20, 10]} intensity={1.2} />
      <gridHelper args={[80, 40, "#25324d", "#18233a"]} />
      {geometry && <MemberLines nodes={geometry.nodes} members={geometry.members} />}
      <OrbitControls />
    </Canvas>
  );
}
